/*
 * jerm.c - terminal emulator
 * Copyright (C) 2000 by candy
 * $Id: jerm.c,v 1.3 2000/05/02 03:28:39 candy Exp $
 */
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sys/types.h>
#include <sys/time.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>


static char *myname;

enum parity_t {
	P_NONE,
	P_EVEN,
	P_ODD,
};

enum flow_t {
	F_NONE,
	F_HARD,
	F_X,
};

static int speed = B9600; /* B38400 - B75 */
static enum parity_t parity = P_NONE;
static int data_bit = CS8;
static int stop_bit = 1;
static enum flow_t flow_control = F_NONE;
static int FUCK_MODE; /* TA-100 �� */

static int quit_flag;

/*
 * select on 2 file descriptors.
 */
static int
sel2(fd_set *m, int f1, int f2)
{
	int maxfd = f1 > f2 ? f1 : f2;
	FD_ZERO(m);
	FD_SET(f1, m);
	FD_SET(f2, m);
	errno = 0;
	return select(maxfd + 1, m, NULL, NULL, NULL);
}/* sel2 */

/*
 * host:port �� TCP ��³��
 * �����åȤ��֤���
 */
static int
conn(const char *host, int port)
{
	int so = -1;
	struct hostent *hp = gethostbyname(host);
	if (hp != NULL) {
		struct sockaddr_in sin;
		memset(&sin, '\0', sizeof(sin));
		sin.sin_family = hp->h_addrtype; /* AF_INET */
		memmove(&sin.sin_addr.s_addr, hp->h_addr_list[0], hp->h_length);
		sin.sin_port = htons(port);
		so = socket(sin.sin_family, SOCK_STREAM, 0);
		if (so >= 0) {
			int err = connect(so, (struct sockaddr *)&sin, sizeof(sin));
			if (err < 0) {
				perror("connect");
				close(so);
				so = -1;
			}
		}
		else
			perror("socket");
	}
	else
		perror("gethostbyname");
	return so;
}/* conn */

/*
 * �����åȤ� size_ �Х���������
 */
static int
so_write(int so, const void *buf, size_t size_)
{
	int err = 0;
	int size = size_;
	const char *mv = buf;
	while (err == 0 && size >= 1) {
		int wrote = write(so, mv, size);
		if (wrote >= size) {
			size -= wrote;
			mv += wrote;
		}
		else
			err = -1;
	}/* while */
	if (err == 0)
		err = size_;
	return err;
}/* so_write */

/*
 *
 */
static struct termios tio_save;
static int ti_fd;

/*
 * ������˥����ߥʥ�ξ��֤��᤹��
 */
static void
restore_local_terminal(void)
{
	tcsetattr(ti_fd, TCSANOW, &tio_save);
}/* restore_local_terminal */

/*
 * �����ߥʥ�ξ��֤���¸��
 */
static int
save_local_terminal(int fd)
{
	int err = tcgetattr(fd, &tio_save);
	if (err < 0) {
		perror("tcgetattr");
	}
	else {
		ti_fd = fd;
		atexit(restore_local_terminal);
	}
	return err;
}/* save_local_terminal */

/*
 * �����ߥʥ�� raw �⡼�ɤˤ��롣
 */
static int
make_local_raw(int fd)
{
	int err = save_local_terminal(fd);
	if (err == 0) {
		struct termios tio;
		if ((err = tcgetattr(fd, &tio)) < 0)
			perror("tcgetattr");
		else {
			cfmakeraw(&tio);
			if ((err = tcsetattr(fd, TCSANOW, &tio)) < 0)
				perror("tcsetattr");
		}
	}
	return err;
}/* make_local_raw */

/*
 * ����
 */
static int
print_nl(FILE *fp)
{
	return fprintf(fp, "\r\n");
}/* print_nl */

/*
 * �����ߥʥ�ξ��֤�ɽ����
 * stty -a �ߤ����ʤ�ġ�
 */
static void
print_status(const struct termios *tio)
{
	int cs;
	char *csstr = "?";
	speed_t ispeed = cfgetispeed(tio);
	speed_t ospeed = cfgetospeed(tio);
	printf(" ispeed %d", ispeed);
	printf(" ospeed %d", ospeed);
	print_nl(stdout);
	printf(" %cIGNBRK", (tio->c_iflag & IGNBRK) ? '+' : '-');
	printf(" %cBRKINT", (tio->c_iflag & BRKINT) ? '+' : '-');
	printf(" %cIGNPAR", (tio->c_iflag & IGNPAR) ? '+' : '-');
	printf(" %cPARMRK", (tio->c_iflag & PARMRK) ? '+' : '-');
	printf(" %cINPCK", (tio->c_iflag & INPCK) ? '+' : '-');
	printf(" %cISTRIP", (tio->c_iflag & ISTRIP) ? '+' : '-');
	printf(" %cINLCR", (tio->c_iflag & INLCR) ? '+' : '-');
	printf(" %cIGNCR", (tio->c_iflag & IGNCR) ? '+' : '-');
	printf(" %cICRNL", (tio->c_iflag & ICRNL) ? '+' : '-');
	printf(" %cIXON", (tio->c_iflag & IXON) ? '+' : '-');
	printf(" %cIXOFF", (tio->c_iflag & IXOFF) ? '+' : '-');
	printf(" %cIXANY", (tio->c_iflag & IXANY) ? '+' : '-');
	printf(" %cIMAXBEL", (tio->c_iflag & IMAXBEL) ? '+' : '-');
	print_nl(stdout);
	printf(" %cOPOST", (tio->c_oflag & OPOST) ? '+' : '-');
	printf(" %cONLCR", (tio->c_oflag & ONLCR) ? '+' : '-');
	printf(" %cOXTABS", (tio->c_oflag & OXTABS) ? '+' : '-');
	printf(" %cONOEOT", (tio->c_oflag & ONOEOT) ? '+' : '-');
	print_nl(stdout);
	cs = tio->c_cflag & CSIZE;
	switch (cs) {
	case CS5: csstr = "5"; break;
	case CS6: csstr = "6"; break;
	case CS7: csstr = "7"; break;
	case CS8: csstr = "8"; break;
	default: csstr = "?"; break;
	}/* switch */
	printf(" cs%s", csstr);
	printf(" %cCSTOPB", (tio->c_cflag & CSTOPB) ? '+' : '-');
	printf(" %cCREAD", (tio->c_cflag & CREAD) ? '+' : '-');
	printf(" %cPARENB", (tio->c_cflag & PARENB) ? '+' : '-');
	printf(" %cPARODD", (tio->c_cflag & PARODD) ? '+' : '-');
	printf(" %cHUPCL", (tio->c_cflag & HUPCL) ? '+' : '-');
	printf(" %cCLOCAL", (tio->c_cflag & CLOCAL) ? '+' : '-');
	printf(" %cCCTS_OFLOW", (tio->c_cflag & CCTS_OFLOW) ? '+' : '-');
	printf(" %cCRTSCTS", (tio->c_cflag & CRTSCTS) ? '+' : '-');
	printf(" %cCRTS_IFLOW", (tio->c_cflag & CRTS_IFLOW) ? '+' : '-');
	printf(" %cMDMBUF", (tio->c_cflag & MDMBUF) ? '+' : '-');
	printf(" %cECHOKE", (tio->c_lflag & ECHOKE) ? '+' : '-');
	printf(" %cECHOE", (tio->c_lflag & ECHOE) ? '+' : '-');
	printf(" %cECHO", (tio->c_lflag & ECHO) ? '+' : '-');
	printf(" %cECHONL", (tio->c_lflag & ECHONL) ? '+' : '-');
	printf(" %cECHOPRT", (tio->c_lflag & ECHOPRT) ? '+' : '-');
	printf(" %cECHOCTL", (tio->c_lflag & ECHOCTL) ? '+' : '-');
	printf(" %cISIG", (tio->c_lflag & ISIG) ? '+' : '-');
	printf(" %cICANON", (tio->c_lflag & ICANON) ? '+' : '-');
	printf(" %cALTWERASE", (tio->c_lflag & ALTWERASE) ? '+' : '-');
	printf(" %cIEXTEN", (tio->c_lflag & IEXTEN) ? '+' : '-');
	print_nl(stdout);
	printf(" %cEXTPROC", (tio->c_lflag & EXTPROC) ? '+' : '-');
	printf(" %cTOSTOP", (tio->c_lflag & TOSTOP) ? '+' : '-');
	printf(" %cFLUSHO", (tio->c_lflag & FLUSHO) ? '+' : '-');
	printf(" %cNOKERNINFO", (tio->c_lflag & NOKERNINFO) ? '+' : '-');
	printf(" %cPENDIN", (tio->c_lflag & PENDIN) ? '+' : '-');
	printf(" %cNOFLSH", (tio->c_lflag & NOFLSH) ? '+' : '-');
	print_nl(stdout);
}/* print_status */

/*
 * �������Х��ѿ��򻲾Ȥ��ơ������ߥʥ�ξ���
 * (speed, parity, data bits ��)�����ꤹ�롣
 */
static void
set_status(struct termios *tio)
{
	cfsetispeed(tio, speed);
	cfsetospeed(tio, speed);
	tio->c_cflag = (tio->c_cflag & ~CSIZE) | data_bit;
	if (stop_bit == 1)
		tio->c_cflag &= ~CSTOPB;
	else if (stop_bit == 2)
		tio->c_cflag |= CSTOPB;
	switch (parity) {
	case P_NONE:
		tio->c_cflag &= ~PARENB;
		break;
	case P_EVEN:
		tio->c_cflag = (tio->c_cflag | PARENB) & ~PARODD;
		break;
	case P_ODD:
		tio->c_cflag = tio->c_cflag | PARENB | PARODD;
		break;
	}/* switch */
	switch (flow_control) {
	case F_NONE:
		tio->c_cflag &= ~(CCTS_OFLOW | CRTS_IFLOW);
		tio->c_iflag &= ~(IXON | IXOFF);
		break;
	case F_HARD:
		tio->c_cflag |= (CCTS_OFLOW | CRTS_IFLOW);
		tio->c_iflag &= ~(IXON | IXOFF);
		break;
	case F_X:
		tio->c_cflag &= ~(CCTS_OFLOW | CRTS_IFLOW);
		tio->c_iflag |= (IXON | IXOFF);
		break;
	}/* switch */
}/* set_status */

/*
 * ���ꤵ�줿�ե�����ϥ�ɥ�Υ����ߥʥ���֤�ɽ����
 */
static int
print_fdstatus(int fd)
{
	int err = -1;
	struct termios tio;
	if (tcgetattr(fd, &tio) < 0)
		perror("tcgetattr");
	else {
		print_status(&tio);
		err = 0;
	}
	return err;
}/* print_status */

/*
 * ���ꤵ�줿�ե�����ϥ�ɥ�Υ����ߥʥ�ξ��֤��������롣
 * raw �⡼�ɤˤ��ơ�CLOCAL �����ꤹ�롣
 */
static int
fd_init(int fd)
{
	struct termios tio;
	int err = -1;
	if (tcgetattr(fd, &tio) < 0)
		perror("tcgetattr");
	else {
		cfmakeraw(&tio);
		tio.c_cflag |= CLOCAL; /* do not send SIGHUP to me! */
		if (tcsetattr(fd, TCSANOW, &tio) < 0)
			perror("tcsetattr");
		else
			err = 0;
	}
	return err;
}/* fd_init */

/*
 * ���ꤵ�줿�ե�����ϥ�ɥ�ˤĤ��ơ�
 * �������Х��ѿ��򻲾Ȥ��ơ������ߥʥ�ξ���
 * (speed, parity, data bits ��)�����ꤹ�롣
 */
static int
set_fdstatus(int fd)
{
	struct termios tio;
	int err = -1;
	if (tcgetattr(fd, &tio) < 0)
		perror("tcgetattr");
	else {
		set_status(&tio);
		if (tcsetattr(fd, TCSANOW, &tio) < 0)
			perror("tcsetattr");
		else
			err = 0;
	}
	return err;
}/* set_fdstatus */

/*
 * ��⡼�Ȥ���ǡ������������褿������
 */
static int
read_remote(int localfd, int remotefd)
{
	unsigned char lbuf[80];
	int err = read(remotefd, lbuf, sizeof(lbuf));
	if (err < 0)
		perror("remote read");
	else if (err == 0) {
		fprintf(stderr, "remote closed");
		err = -1;
	}
	else {
		write(1, lbuf, err);
		err = 0;
	}
	return err;
}/* read_remote */

/*
 * ���������� (���ԡ������) �θ�� cmd �����Ϥ��줿������
 */
static int
do_escape(int cmd, int localfd, int remotefd)
{
	int err = 0;
	char obuf[2];
	switch (cmd) {
	case '.':
		quit_flag = 1; /* �ץ�����ཪλ */
		break;
	default:
		obuf[0] = '~';
		obuf[1] = cmd;
		if (so_write(remotefd, obuf, 2) != 2) {
			perror("write remote");
			err = -1;
		}
		break;
	}/* switch */
	return err;
}/* do_escape */

/*
 * �����ܡ��ɤ������Ϥ����ä�������
 */
static int
read_local(int localfd, int remotefd)
{
	static int lastch = EOF;
	unsigned char lbuf[1];
	int err = read(localfd, lbuf, sizeof(lbuf));
	if (err < 0)
		perror("local read");
	else if (err == 0) {
		fprintf(stderr, "local closed");
		err = -1;
	}
	else {
		if ((lastch == '\n' || lastch == '\r') && lbuf[0] == '~') {
			err = read(localfd, lbuf, sizeof(lbuf));
			if (err < 0)
				perror("local read");
			else if (err == 0) {
				fprintf(stderr, "local closed");
				err = -1;
			}
			else {
				err = do_escape(lbuf[0], localfd, remotefd);
				lastch = lbuf[0];
			}
		}
		else {
			if (FUCK_MODE && lbuf[0] == '\r') {
				char obuf[2];
				obuf[0] = '\r';
				obuf[1] = '\n';
				err = so_write(remotefd, &obuf, 2);
			}
			else
				err = so_write(remotefd, lbuf, err);
			if (err < 0) {
				perror("write remote");
			}
			else
				err = 0;
			lastch = lbuf[0];
		}
	}
	return err;
}/* read_local */

/*
 * �ᥤ��롼��
 */
static int
fnain(int localfd, int remotefd)
{
	int err = 0;
	quit_flag = 0;
	while (quit_flag == 0 && err == 0) {
		fd_set fds;
		err = sel2(&fds, localfd, remotefd);
		if (err == -1)
			perror("select");
		else if (err == 0) {
			/* timeout */
		}
		else {
			if (FD_ISSET(remotefd, &fds)) {
				err = read_remote(localfd, remotefd);
			}
			if (FD_ISSET(localfd, &fds)) {
				err = read_local(localfd, remotefd);
			}
		}
	}/* while */
	return err;
}/* fnain */

/*
 * ���ꥢ��ݡ��Ȥ���ʤ��ơ�
 * host:port �� TCP ����³�����̿����롣
 * telnet(1) �ߤ������ۡ�
 */
static int
oain(const char *host, int port)
{
	int err = -1;
	int so = conn(host, port);
	if (so >= 0) {
		if (make_local_raw(0) == 0)
			err = fnain(0, so);
		close(so);
	}
	return err;
}/* oain */

/*
 * �ե�����̾ dev ���̤��ƥ��ꥢ���̿���Ԥ���
 */
static int
nain(const char *dev)
{
	int err = -1;
	int remotefd = open(dev, O_RDWR);
	if (remotefd < 0)
		perror(dev);
	else {
		if (make_local_raw(0) == 0 && fd_init(remotefd) == 0 && set_fdstatus(remotefd) == 0) {
			print_fdstatus(remotefd);
			err = fnain(0, remotefd);
		}
		close(remotefd);
	}
	return err;
}/* nain */

/*
 *
 */
static char *usage_msg =
	"usage1: %s [optinos] device\n"
	"\t-b speed\tspeed\n"
	"\t-p [none|even|odd]\tparity\n"
	"\t-d [7|8]\tdata bits\n"
	"\t-s [1|2|1.5]\tstop bit\n"
	"\t-f [none|x|hard]\tflow control\n"
	"\t-F\tSet FUCK MODE for TA-100KR/RA SYSTEMS CORP.\n"
	"usage2: %s [-P port(257)] TA-100.ip.address\n"
	;

/*
 *
 */
int
main(int argc, char *argv[])
{
	int ex = 1, ch, show_usage = 0;
	int port = 257;
	myname = argv[0];
	while ((ch = getopt(argc, argv, "b:d:f:Fp:P:s:V")) != EOF) {
		switch (ch) {
			int x;
		default:
		case 'V':
			show_usage = 1;
			break;
		case 'b':
			x = strtol(optarg, NULL, 10);
			switch (x) {
			case B0: case B50: case B75: case B110: case B134: case B150:
			case B200: case B300: case B600: case B1200: case B1800:
			case B2400: case B4800: case B9600: case B19200: case B38400:
				speed = x;
				break;
			default: show_usage = 1; break;
			}/* switch */
			break;
		case 'd':
			x = strtol(optarg, NULL, 10);
			switch (x) {
			case 8: data_bit = CS8; break;
			case 7: data_bit = CS7; break;
			default: show_usage = 1; break;
			}/* switch */
			break;
		case 'f':
			switch (optarg[0]) {
			case 'n': flow_control = F_NONE; break;
			case 'x': flow_control = F_X; break;
			case 'h': flow_control = F_HARD; break;
			default: show_usage = 1; break;
			}/* switch */
			break;
		case 'F':
			FUCK_MODE = 1;
			speed = B9600;
			data_bit = CS8;
			stop_bit = 1;
			parity = P_EVEN;
			flow_control = F_HARD;
			break;
		case 'p':
			switch (optarg[0]) {
			case 'n': parity = P_NONE; break;
			case 'e': parity = P_EVEN; break;
			case 'o': parity = P_ODD; break;
			default: show_usage = 1; break;
			}/* switch */
			break;
		case 'P':
			port = strtol(optarg, NULL, 0);
			break;
		case 's':
			if (strcmp(optarg, "1") == 0)
				stop_bit = 1;
			else if (strcmp(optarg, "2") == 0)
				stop_bit = 2;
			else if (strcmp(optarg, "1.5") == 0)
				stop_bit = 3;
			else	
				show_usage = 1;
			break;
		}/* switch */
	}/* while */
	if (argc - optind != 1)
		show_usage++;
	if (show_usage)
		fprintf(stderr, usage_msg, myname, myname);
	else {
		char *target = argv[optind];
		printf("Jerminal version 0.8086  Copyright (C) 2000 by candy\n");
		printf("Type \"Ctrl-M ~ .\" to exit.\n");
		if (*target == '/')
			nain(argv[optind]);
		else
			oain(argv[optind], port);
		ex = 0;
	}
	return ex;
}/* main */
