/*
 * jerm.c - terminal emulator
 * Copyright (C) 2000, 2001, 2002 by candy
 * $Id: jerm.c,v 1.13 2002/08/03 06:55:59 candy Exp candy $
 */
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sys/types.h>
#include <sys/time.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>


static char *myname;

enum parity_t {
	P_NONE,
	P_EVEN,
	P_ODD,
};

enum flow_t {
	F_NONE,
	F_HARD,
	F_X,
};

static int speed = B9600; /* B38400 - B75 */
static enum parity_t parity = P_NONE;
static int data_bit = CS8;
static int stop_bit = 1;
static enum flow_t flow_control = F_NONE;
static int FUCK_MODE; /* TA-100 �� */
static int hex_mode; /* hex dump �⡼�� */
static int pipe_mode; /* ���ꥢ��˿�ή�� */
static int rockwell_mode;
static int jdebug;

static int quit_flag;

/*
 * select on 2 file descriptors.
 */
static int
sel2(fd_set *m, int f1, int f2)
{
	int maxfd = f1 > f2 ? f1 : f2;
	FD_ZERO(m);
	FD_SET(f1, m);
	FD_SET(f2, m);
	errno = 0;
	return select(maxfd + 1, m, NULL, NULL, NULL);
}/* sel2 */

/*
 * host:port �� TCP ��³��
 * �����åȤ��֤���
 */
static int
conn(const char *host, int port)
{
	int so = -1;
	struct hostent *hp = gethostbyname(host);
	if (hp != NULL) {
		struct sockaddr_in sin;
		memset(&sin, '\0', sizeof(sin));
		sin.sin_family = hp->h_addrtype; /* AF_INET */
		memmove(&sin.sin_addr.s_addr, hp->h_addr_list[0], hp->h_length);
		sin.sin_port = htons(port);
		so = socket(sin.sin_family, SOCK_STREAM, 0);
		if (so >= 0) {
			int err = connect(so, (struct sockaddr *)&sin, sizeof(sin));
			if (err < 0) {
				perror("connect");
				close(so);
				so = -1;
			}
		}
		else
			perror("socket");
	}
	else
		perror("gethostbyname");
	return so;
}/* conn */

/*
 * �����åȤ� size_ �Х���������
 */
static int
so_write(int so, const void *buf, size_t size_)
{
	int err = 0;
	int size = size_;
	const char *mv = buf;
	while (err == 0 && size >= 1) {
		int wrote = write(so, mv, size);
		if (wrote >= size) {
			size -= wrote;
			mv += wrote;
		}
		else
			err = -1;
	}/* while */
	if (err == 0)
		err = size_;
	return err;
}/* so_write */

/*
 *
 */
static struct termios tio_save;
static int ti_fd;

/*
 * ������˥����ߥʥ�ξ��֤��᤹��
 */
static void
restore_local_terminal(void)
{
	tcsetattr(ti_fd, TCSANOW, &tio_save);
}/* restore_local_terminal */

/*
 * �����ߥʥ�ξ��֤���¸��
 */
static int
save_local_terminal(int fd)
{
	int err = tcgetattr(fd, &tio_save);
	if (err < 0) {
		perror("tcgetattr");
	}
	else {
		ti_fd = fd;
		atexit(restore_local_terminal);
	}
	return err;
}/* save_local_terminal */

/*
 * �����ߥʥ�� raw �⡼�ɤˤ��롣
 */
static int
make_local_raw(int fd)
{
	int err = 0;
	if (isatty(fd)) {
		err = save_local_terminal(fd);
		if (err == 0) {
			struct termios tio;
			if ((err = tcgetattr(fd, &tio)) < 0)
				perror("tcgetattr");
			else {
				cfmakeraw(&tio);
				if ((err = tcsetattr(fd, TCSANOW, &tio)) < 0)
					perror("tcsetattr");
			}
		}
	}
	return err;
}/* make_local_raw */

/*
 * ����
 */
static char *NL = "\r\n";

/*
 * �����ߥʥ�ξ��֤�ɽ����
 * stty -a �ߤ����ʤ�ġ�
 */
static void
print_status(const struct termios *tio)
{
	int cs;
	char *csstr = "?";
	speed_t ispeed = cfgetispeed(tio);
	speed_t ospeed = cfgetospeed(tio);
	fprintf(stderr, " ispeed %d", ispeed);
	fprintf(stderr, " ospeed %d", ospeed);
	fprintf(stderr, "%s", NL);
	fprintf(stderr, " %cIGNBRK", (tio->c_iflag & IGNBRK) ? '+' : '-');
	fprintf(stderr, " %cBRKINT", (tio->c_iflag & BRKINT) ? '+' : '-');
	fprintf(stderr, " %cIGNPAR", (tio->c_iflag & IGNPAR) ? '+' : '-');
	fprintf(stderr, " %cPARMRK", (tio->c_iflag & PARMRK) ? '+' : '-');
	fprintf(stderr, " %cINPCK", (tio->c_iflag & INPCK) ? '+' : '-');
	fprintf(stderr, " %cISTRIP", (tio->c_iflag & ISTRIP) ? '+' : '-');
	fprintf(stderr, " %cINLCR", (tio->c_iflag & INLCR) ? '+' : '-');
	fprintf(stderr, " %cIGNCR", (tio->c_iflag & IGNCR) ? '+' : '-');
	fprintf(stderr, " %cICRNL", (tio->c_iflag & ICRNL) ? '+' : '-');
	fprintf(stderr, " %cIXON", (tio->c_iflag & IXON) ? '+' : '-');
	fprintf(stderr, " %cIXOFF", (tio->c_iflag & IXOFF) ? '+' : '-');
	fprintf(stderr, " %cIXANY", (tio->c_iflag & IXANY) ? '+' : '-');
	fprintf(stderr, " %cIMAXBEL", (tio->c_iflag & IMAXBEL) ? '+' : '-');
	fprintf(stderr, "%s", NL);
	fprintf(stderr, " %cOPOST", (tio->c_oflag & OPOST) ? '+' : '-');
	fprintf(stderr, " %cONLCR", (tio->c_oflag & ONLCR) ? '+' : '-');
	fprintf(stderr, " %cOXTABS", (tio->c_oflag & OXTABS) ? '+' : '-');
	fprintf(stderr, " %cONOEOT", (tio->c_oflag & ONOEOT) ? '+' : '-');
	fprintf(stderr, "%s", NL);
	cs = tio->c_cflag & CSIZE;
	switch (cs) {
	case CS5: csstr = "5"; break;
	case CS6: csstr = "6"; break;
	case CS7: csstr = "7"; break;
	case CS8: csstr = "8"; break;
	default: csstr = "?"; break;
	}/* switch */
	fprintf(stderr, " cs%s", csstr);
	fprintf(stderr, " %cCSTOPB", (tio->c_cflag & CSTOPB) ? '+' : '-');
	fprintf(stderr, " %cCREAD", (tio->c_cflag & CREAD) ? '+' : '-');
	fprintf(stderr, " %cPARENB", (tio->c_cflag & PARENB) ? '+' : '-');
	fprintf(stderr, " %cPARODD", (tio->c_cflag & PARODD) ? '+' : '-');
	fprintf(stderr, " %cHUPCL", (tio->c_cflag & HUPCL) ? '+' : '-');
	fprintf(stderr, " %cCLOCAL", (tio->c_cflag & CLOCAL) ? '+' : '-');
	fprintf(stderr, " %cCCTS_OFLOW", (tio->c_cflag & CCTS_OFLOW) ? '+' : '-');
	fprintf(stderr, " %cCRTSCTS", (tio->c_cflag & CRTSCTS) ? '+' : '-');
	fprintf(stderr, " %cCRTS_IFLOW", (tio->c_cflag & CRTS_IFLOW) ? '+' : '-');
	fprintf(stderr, " %cMDMBUF", (tio->c_cflag & MDMBUF) ? '+' : '-');
	fprintf(stderr, " %cECHOKE", (tio->c_lflag & ECHOKE) ? '+' : '-');
	fprintf(stderr, " %cECHOE", (tio->c_lflag & ECHOE) ? '+' : '-');
	fprintf(stderr, " %cECHO", (tio->c_lflag & ECHO) ? '+' : '-');
	fprintf(stderr, " %cECHONL", (tio->c_lflag & ECHONL) ? '+' : '-');
	fprintf(stderr, " %cECHOPRT", (tio->c_lflag & ECHOPRT) ? '+' : '-');
	fprintf(stderr, " %cECHOCTL", (tio->c_lflag & ECHOCTL) ? '+' : '-');
	fprintf(stderr, " %cISIG", (tio->c_lflag & ISIG) ? '+' : '-');
	fprintf(stderr, " %cICANON", (tio->c_lflag & ICANON) ? '+' : '-');
	fprintf(stderr, " %cALTWERASE", (tio->c_lflag & ALTWERASE) ? '+' : '-');
	fprintf(stderr, " %cIEXTEN", (tio->c_lflag & IEXTEN) ? '+' : '-');
	fprintf(stderr, "%s", NL);
	fprintf(stderr, " %cEXTPROC", (tio->c_lflag & EXTPROC) ? '+' : '-');
	fprintf(stderr, " %cTOSTOP", (tio->c_lflag & TOSTOP) ? '+' : '-');
	fprintf(stderr, " %cFLUSHO", (tio->c_lflag & FLUSHO) ? '+' : '-');
	fprintf(stderr, " %cNOKERNINFO", (tio->c_lflag & NOKERNINFO) ? '+' : '-');
	fprintf(stderr, " %cPENDIN", (tio->c_lflag & PENDIN) ? '+' : '-');
	fprintf(stderr, " %cNOFLSH", (tio->c_lflag & NOFLSH) ? '+' : '-');
	fprintf(stderr, "%s", NL);
	fflush(stderr);
}/* print_status */

/*
 * �������Х��ѿ��򻲾Ȥ��ơ������ߥʥ�ξ���
 * (speed, parity, data bits ��)�����ꤹ�롣
 */
static void
set_status(struct termios *tio)
{
	cfsetispeed(tio, speed);
	cfsetospeed(tio, speed);
	tio->c_cflag = (tio->c_cflag & ~CSIZE) | data_bit;
	if (stop_bit == 1)
		tio->c_cflag &= ~CSTOPB;
	else if (stop_bit == 2)
		tio->c_cflag |= CSTOPB;
	switch (parity) {
	case P_NONE:
		tio->c_cflag &= ~PARENB;
		break;
	case P_EVEN:
		tio->c_cflag = (tio->c_cflag | PARENB) & ~PARODD;
		break;
	case P_ODD:
		tio->c_cflag = tio->c_cflag | PARENB | PARODD;
		break;
	}/* switch */
	switch (flow_control) {
	case F_NONE:
		tio->c_cflag &= ~(CCTS_OFLOW | CRTS_IFLOW);
		tio->c_iflag &= ~(IXON | IXOFF);
		break;
	case F_HARD:
		tio->c_cflag |= (CCTS_OFLOW | CRTS_IFLOW);
		tio->c_iflag &= ~(IXON | IXOFF);
		break;
	case F_X:
		tio->c_cflag &= ~(CCTS_OFLOW | CRTS_IFLOW);
		tio->c_iflag |= (IXON | IXOFF);
		break;
	}/* switch */
}/* set_status */

/*
 * ���ꤵ�줿�ե�����ϥ�ɥ�Υ����ߥʥ���֤�ɽ����
 */
static int
print_fdstatus(int fd)
{
	int err = -1;
	struct termios tio;
	if (tcgetattr(fd, &tio) < 0)
		perror("tcgetattr");
	else {
		print_status(&tio);
		err = 0;
	}
	return err;
}/* print_fdstatus */

/*
 * ���ꤵ�줿�ե�����ϥ�ɥ�Υ����ߥʥ�ξ��֤��������롣
 * raw �⡼�ɤˤ��ơ�CLOCAL �����ꤹ�롣
 */
static int
fd_init(int fd)
{
	struct termios tio;
	int err = -1;
	if (tcgetattr(fd, &tio) < 0)
		perror("tcgetattr");
	else {
		cfmakeraw(&tio);
		tio.c_cflag |= CLOCAL; /* do not send SIGHUP to me! */
		if (tcsetattr(fd, TCSANOW, &tio) < 0)
			perror("tcsetattr");
		else
			err = 0;
	}
	return err;
}/* fd_init */

/*
 * ���ꤵ�줿�ե�����ϥ�ɥ�ˤĤ��ơ�
 * �������Х��ѿ��򻲾Ȥ��ơ������ߥʥ�ξ���
 * (speed, parity, data bits ��)�����ꤹ�롣
 */
static int
set_fdstatus(int fd)
{
	struct termios tio;
	int err = -1;
	if (tcgetattr(fd, &tio) < 0)
		perror("tcgetattr");
	else {
		set_status(&tio);
		if (tcsetattr(fd, TCSANOW, &tio) < 0)
			perror("tcsetattr");
		else
			err = 0;
	}
	return err;
}/* set_fdstatus */

/*
 *
 */

static int
chardump(const void *buf_, size_t size)
{
	const unsigned char *buf = buf_;
	int i;
	printf(" |");
	for (i = 0; i < size; i++) {
		if (buf[i] >= ' ' && buf[i] < 0x7f)
			printf("%c", buf[i]);
		else
			printf(".");
	}/* for */
	printf("%s", NL);
	fflush(stdout);
	return 0;
}/* chardump */

static unsigned char hex_buf[16];
static int hex_count;

static int
hexdump_start(void)
{
	fprintf(stderr, "[HEX MODE]%s", NL);
	hex_count = 0;
	return 0;
}/* hexdump_start */

static int
hexdump_stop(void)
{
	if (hex_count > 0)
		chardump(hex_buf, hex_count);
	fprintf(stderr, "[NORMAL MODE]%s", NL);
	return 0;
}/* hexdump_stop */

/*
 *
 */
static int
hexdump(const void *buf_, size_t size)
{
	const unsigned char *buf = buf_;
	int i;
	for (i = 0; i < size; i++) {
		printf("%02x ", buf[i]);
		hex_buf[hex_count++] = buf[i];
		if (hex_count == sizeof(hex_buf)) {
			chardump(hex_buf, hex_count);
			hex_count = 0;
		}
	}/* for */
	return 0;
}/* hexdump */

struct jm1000_t {
	unsigned short stime[2];
	unsigned short seq;
	unsigned short sseq;
	unsigned short navval;
	unsigned short navtype;
	unsigned short nmeas;
	unsigned short polar;
	unsigned short gweek;
	unsigned short sweek[2];
	unsigned short nsweek[2];
	unsigned short utcday;
	unsigned short utcmon;
	unsigned short utcyear;
	unsigned short utchour;
	unsigned short utcmin;
	unsigned short utcsec;
	unsigned short utcnsec[2];
	unsigned short lat[2];
	unsigned short lon[2];
	unsigned short height[2];
	unsigned short gsep;
	unsigned short speed[2];
	unsigned short course;
	unsigned short mvar;
	unsigned short climb;
	unsigned short mapd;
	unsigned short herr[2];
	unsigned short verr[2];
	unsigned short terr[2];
	unsigned short hverr;
	unsigned short bias[2];
	unsigned short biassd[2];
	unsigned short drift[2];
	unsigned short driftsd[2];
	unsigned short dsum;
};

struct jm1108_t {
	unsigned short stime[2];
	unsigned short seq;
	unsigned short reserved[5];
	unsigned short sweek[2];
	short offs;
	unsigned short offns[2];
	unsigned short flags;
	unsigned short dsum;
};

static time_t
get_gpsweek(int utc_of_week)
{
	time_t ret = 0;
	int err;
	struct timeval tv;
	err = gettimeofday(&tv, NULL);
	if (err == 0) {
		struct tm tm = *gmtime(&tv.tv_sec);
		int sec_of_week = tm.tm_wday * 86400 + tm.tm_hour * 3600 + tm.tm_min * 60 + tm.tm_sec;
		/*int diff = utc_of_week - sec_of_week;*/
		ret = tv.tv_sec - sec_of_week;
	}
	else
		perror("gettimeofday");
	return ret;
}/* get_gpsweek */


static int
get_now(int utc_of_week)
{
	time_t gps0 = get_gpsweek(utc_of_week);
	time_t t = gps0 + utc_of_week;
	return t;
}/* get_now */

#define UDI(v_) (((unsigned long)(v_)[1] << 16) | (v_)[0])


static int
decode(unsigned short *dt, int count)
{
	int id = dt[1];
	/*int dlen = dt[2];*/
	struct jm1000_t *jm1000;
	struct jm1108_t *jm1108;
	switch (id)  {
	case 1000:
		jm1000 = (struct jm1000_t *)&dt[5];
		printf("%d %04d/%02d/%02d %02d:%02d:%02d (%lu)\r\n",
			jm1000->seq,
			jm1000->utcyear,
			jm1000->utcmon,
			jm1000->utcday,
			jm1000->utchour,
			jm1000->utcmin,
			jm1000->utcsec,
			UDI(jm1000->utcnsec));
		break;
	case 1108:
		jm1108 = (struct jm1108_t *)&dt[5];
		{
			time_t t = get_now(UDI(jm1108->sweek));
			struct tm tm = *localtime(&t);
			printf("%d UTCofWeek %lu GPStoUTC %d.%06ld A/V=%d GPS/UTC %d %04d/%02d/%02d %02d:%02d:%02d\r\n",
				jm1108->seq,
				UDI(jm1108->sweek),
				jm1108->offs,
				UDI(jm1108->offns),
				jm1108->flags & 1,
				jm1108->flags & 2,
				tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday,
				tm.tm_hour, tm.tm_min, tm.tm_sec
				);
		}
		break;
	default:
		printf("\a%04x id=%04x(%d) size=%04x %04x sum=%04x\r\n", dt[0], dt[1], dt[1], dt[2], dt[3], dt[4]);
		break;
	}/* switch */
	return 0;
}/* decode */

#define WORD_MAX 300
static unsigned short bdata[WORD_MAX];



static int
rockwell2(int ch)
{
	static int stat;
	static int soh_del;
	static int message_id;
	static int data_word_count;
	static int dcl0_qran;
	static int header_checksum;
	static int wc;
	int sum;
	int err = 0;
	switch (stat) {
	case 0:
		bdata[0] = ch;
		if (ch == 0x81ff) {
			soh_del = ch;
			if (jdebug) fprintf(stderr, "soh_del = %04x\r\n", ch);
			stat++;
			fprintf(stderr, ":");
		}
		else {
			if (jdebug) fprintf(stderr, "not soh_del : %04x\r\n", ch);
		}
		break;
	case 1:
		bdata[1] = ch;
		message_id = ch;
		if (jdebug) fprintf(stderr, "message_id = %04x (%d)\r\n", ch, ch);
		fprintf(stderr, "%d ", ch);
		stat++;
		break;
	case 2:
		bdata[2] = ch;
		data_word_count = ch;
		if (jdebug) fprintf(stderr, "data_word_count = %04x\r\n", ch);
		if (data_word_count >= WORD_MAX) {
			fprintf(stderr, "data_word_count %d >= %d\r\n", data_word_count, WORD_MAX);
		}
		stat++;
		break;
	case 3:	
		bdata[3] = ch;
		dcl0_qran = ch;
		if (jdebug) fprintf(stderr, "dcl0_qran = %04x\r\n", ch);
		stat++;
		break;
	case 4:
		bdata[4] = ch;
		header_checksum = ch;
		wc = 0;
		stat++;
		sum = (-(0x81ff + message_id + data_word_count + dcl0_qran)) & 0xffff;
		if (jdebug) fprintf(stderr, "header_checksum = %04x calc = %04x\r\n", ch, sum);
		if (sum != header_checksum) {
			fprintf(stderr, "checksum error: header = %04x, calc = %04x\r\n", header_checksum, sum);
			stat = 0;
			err = -1;
		}
		sum = 0;
		break;
	case 5:
		if (5 + wc < WORD_MAX)
			bdata[5 + wc] = ch;
		if (wc < data_word_count) {
			if (jdebug) fprintf(stderr, " %d=%04x", wc + 6, ch);
			sum = (sum + ch) & 0xffff;
		}
		else {
			sum = -sum & 0xffff;
			if (jdebug) fprintf(stderr, "\r\n");
			if (jdebug) fprintf(stderr, " data sum = %04x, calc = %04x\r\n", ch, sum);
			if (sum != ch) {
				fprintf(stderr, "checksum error: data sum = %04x, calc = %04x\r\n", ch, sum);
				err = -1;
			}
			else {
				if (5 + wc < WORD_MAX) {
					decode(bdata, 5 + wc + 1);
				}
			}
			stat = 0;
		}
		wc++;
		break;
	}/* switch */
	return err;
}/* rockwell2 */

static int
rockwell(const void *buf_, size_t size)
{
	const unsigned char *buf = buf_;
	static int stat, lo_ch = EOF;
	int i = 0, ch;
	int err;
	for (i = 0; i < size; i++) {
	/* fprintf(stderr, " %02x\r\n", buf[i]); */
		switch (stat) {
		case 0:
			if (buf[i] == 0xff)
				stat = 1;
			break;
		case 1:
			if (buf[i] == 0x81) {
				stat = 2;
				err = rockwell2(0x81ff);
			}
			else if (buf[i] == 0xff)
				stat = 1;
			else
				stat = 0;
			break;
		case 2:
			if (lo_ch == EOF)
				lo_ch = buf[i];
			else {
				ch = lo_ch | (buf[i] << 8);
				lo_ch = EOF;
				err = rockwell2(ch);
				if (err < 0)
					stat = 0;
			}
			break;
		}
	}
	return 0;
}


/*
 * ��⡼�Ȥ���ǡ������������褿������
 */
static int
read_remote(int localfd, int remotefd, FILE *log)
{
	unsigned char lbuf[80];
	int err = read(remotefd, lbuf, sizeof(lbuf));
	if (err < 0)
		perror("remote read");
	else if (err == 0) {
		fprintf(stderr, "remote closed");
		err = -1;
	}
	else {
		if (log != NULL) {
			fwrite(lbuf, 1, err, log);
			fflush(log);
		}
		if (hex_mode)
			err = hexdump(lbuf, err);
		else if (rockwell_mode)
			err = rockwell(lbuf, err);
		else {
			if (fwrite(lbuf, 1, err, stdout) == err)
				err = 0;
		}
		fflush(stdout);
	}
	return err;
}/* read_remote */

/*
 *
 */
static char *
read_line(char *buf, int size, int fd)
{
	int idx = 0, err = 0, done = 0, ch = EOF;
	char *ret = NULL, lbuf[0];
	while (!done  && (err = read(fd, lbuf, 1) > 0)) {
		int i;
		ch = (unsigned char)lbuf[0];
		switch (ch) {
		case '[' - '@':
			done = 1;
			break;
		case 'M' - '@':
		case 'J' - '@':
			if (idx < size)
				buf[idx] = '\0';
			fprintf(stderr, "%s", NL);
			done = 1;
			break;
		case 'H' - '@':
			if (idx >= 1) {
				fprintf(stderr, "\b \b");
				idx--;
			}
			break;
		case 'U' - '@':
			for (i = 0; i < idx; i++)
				fprintf(stderr, "\b \b");
			idx = 0;
			break;
		default:
			if (iscntrl(ch))
				fprintf(stderr, "\a");
			else {
				if (idx + 1 < size) { /* keep 1 for '\0' */
					buf[idx++] = ch;
					fprintf(stderr, "%c", ch);
				}
				else
					fprintf(stderr, "\a");
			}
			break;
		}/* switch */
	}/* while */
	if (err > 0) {
		if (ch != '[' - '@')
			ret = buf;
	}
	return ret;
}/* read_line */

/*
 *
 */
static int
put_file(const char *name, int fd)
{
	int err = -1;
	FILE *fp = fopen(name, "r");
	if (fp == NULL)
		fprintf(stderr, "%s: %s%s", name, strerror(errno), NL);
	else {
		int xx;
		char lbuf[256];
		err = 0;
		while (err == 0 && (xx = fread(lbuf, 1, sizeof(lbuf), fp)) > 0) {
			if (write(fd, lbuf, xx) != xx) {
				fprintf(stderr, "%s: %s%s", name, strerror(errno), NL);
				err = -1;
			}
		}/* while */
		fclose(fp);
	}
	return err;
}/* put_file */

/*
 * ���������� (���ԡ������) �θ�� cmd �����Ϥ��줿������
 * return
 *	0: ok (����������³��)
 *	1: ok (���������׽���)
 *	-1: error (���������׽���)
 */
static int
do_escape(int cmd, int localfd, int remotefd)
{
	int err = 0;
	char obuf[2];
	switch (cmd) {
	case '?':
		fprintf(stderr, "[COMMANDS]%s", NL);
		fprintf(stderr, "[~?]\thelp%s", NL);
		fprintf(stderr, "[~.]\tquit%s", NL);
		fprintf(stderr, "[~~]\tsend '~'%s", NL);
		fprintf(stderr, "[~b]\tsend break%s", NL);
		fprintf(stderr, "[~x]\ttoggle hex mode%s", NL);
		fprintf(stderr, "[~<flie]\tput file%s", NL);
		break;
	case '.':
		quit_flag = 1; /* �ץ�����ཪλ */
		break;
	case '<':
		{
			char lbuf[256];
			fprintf(stderr, "put file>");
			if (read_line(lbuf, sizeof(lbuf), localfd) != NULL) {
				put_file(lbuf, remotefd);	
			}
		}
		break;	
	case '~':
		err = 1;
		if (so_write(remotefd, "~", 1) != 1) {
			perror("write remote");
			err = -1;
		}
		break;
	case 'b':
		if (tcsendbreak(remotefd, 0) < 0) {
			perror("tcsendbreak");
			err = -1;
		}
		break;
	case 'x':
		hex_mode = !hex_mode;
		if (hex_mode)
			hexdump_start();
		else
			hexdump_stop();
		break;
	default:
		err = 1;
		obuf[0] = '~';
		obuf[1] = cmd;
		if (so_write(remotefd, obuf, 2) != 2) {
			perror("write remote");
			err = -1;
		}
		break;
	}/* switch */
	return err;
}/* do_escape */

/*
 * �����ܡ��ɤ������Ϥ����ä�������
 */
static int
read_local(int localfd, int remotefd, FILE *log)
{
	static int lastch = '\n';
	unsigned char lbuf[1];
	int err = read(localfd, lbuf, sizeof(lbuf));
	if (err < 0)
		perror("local read");
	else if (err == 0) {
		fprintf(stderr, "local closed");
		err = -1;
	}
	else {
		if ((lastch == '\n' || lastch == '\r') && lbuf[0] == '~') {
			err = read(localfd, lbuf, sizeof(lbuf));
			if (err < 0)
				perror("local read");
			else if (err == 0) {
				fprintf(stderr, "local closed");
				err = -1;
			}
			else {
				err = do_escape(lbuf[0], localfd, remotefd);
				if (err != 0)
					lastch = lbuf[0];
				if (err == 1)
					err = 0;
			}
		}
		else {
			if (FUCK_MODE && lbuf[0] == '\r') {
				char obuf[2];
				obuf[0] = '\r';
				obuf[1] = '\n';
				err = so_write(remotefd, &obuf, 2);
			}
			else
				err = so_write(remotefd, lbuf, err);
			if (err < 0) {
				perror("write remote");
			}
			else
				err = 0;
			lastch = lbuf[0];
		}
	}
	return err;
}/* read_local */

/*
 * �ᥤ��롼��
 */
static int
fnain(int localfd, int remotefd, FILE *log)
{
	int err = 0;
	if (pipe_mode)
		set_fdstatus(0);
	quit_flag = 0;
	while (quit_flag == 0 && err == 0) {
		fd_set fds;
		err = sel2(&fds, localfd, remotefd);
		if (err == -1)
			perror("select");
		else if (err == 0) {
			/* timeout */
		}
		else {
			if (FD_ISSET(remotefd, &fds)) {
				err = read_remote(localfd, remotefd, log);
			}
			if (FD_ISSET(localfd, &fds)) {
				err = read_local(localfd, remotefd, log);
			}
		}
	}/* while */
	return err;
}/* fnain */

/*
 * ���ꥢ��ݡ��Ȥ���ʤ��ơ�
 * host:port �� TCP ����³�����̿����롣
 * telnet(1) �ߤ������ۡ�
 */
static int
oain(const char *host, int port, FILE *log)
{
	int err = -1;
	int so = conn(host, port);
	if (so >= 0) {
		if (make_local_raw(0) == 0)
			err = fnain(0, so, log);
		close(so);
	}
	return err;
}/* oain */

/*
 * �ե�����̾ dev ���̤��ƥ��ꥢ���̿���Ԥ���
 */
static int
nain(const char *dev, FILE *log)
{
	int err = -1;
	int remotefd = open(dev, O_RDWR);
	if (remotefd < 0)
		perror(dev);
	else {
		if (make_local_raw(0) == 0 && fd_init(remotefd) == 0 && set_fdstatus(remotefd) == 0) {
			print_fdstatus(remotefd);
			err = fnain(0, remotefd, log);
		}
		close(remotefd);
	}
	return err;
}/* nain */

static char *copyright = "Jerminal v0.8088  Copyright (C) 2000, 2001, 2002 by candy";

/*
 *
 */
static char *usage_msg =
	"usage1: %s [optinos] device\n"
	"\t-b speed\tspeed\n"
	"\t-p [none|even|odd]\tparity\n"
	"\t-d [7|8]\tdata bits\n"
	"\t-s [1|2|1.5]\tstop bit\n"
	"\t-f [none|x|hard]\tflow control\n"
	"\t-F\tSet FUCK MODE for TA-100KR/RA SYSTEMS CORP.\n"
	"usage2: %s [-P port(257)] TA-100.ip.address\n"
	"common optinos:\n"
	"\t-l file\tlog file\n"
	"\t-z\ttruncate log file\n"
	"\t-i\tinit stdin/out as same as <device> (pipe mode)\n"
	"\t-j\trockwell binary data mode\n"
	"\t-D\tincrease debug\n"
	;

/*
 *
 */
int
main(int argc, char *argv[])
{
	int ex = 1, ch, show_usage = 0;
	int port = 257, truncate_log = 0;
	char *logfile = NULL;
	myname = argv[0];
	while ((ch = getopt(argc, argv, "b:d:Df:Fijl:p:P:s:V")) != EOF) {
		switch (ch) {
			int x;
		default:
		case 'V':
			show_usage = 1;
			break;
		case 'b':
			x = strtol(optarg, NULL, 10);
			switch (x) {
			case B0: case B50: case B75: case B110: case B134: case B150:
			case B200: case B300: case B600: case B1200: case B1800:
			case B2400: case B4800: case B9600: case B19200: case B38400:
				speed = x;
				break;
			default: show_usage = 1; break;
			}/* switch */
			break;
		case 'd':
			x = strtol(optarg, NULL, 10);
			switch (x) {
			case 8: data_bit = CS8; break;
			case 7: data_bit = CS7; break;
			default: show_usage = 1; break;
			}/* switch */
			break;
		case 'D':
			jdebug++;
			break;
		case 'f':
			switch (optarg[0]) {
			case 'n': flow_control = F_NONE; break;
			case 'x': flow_control = F_X; break;
			case 'h': flow_control = F_HARD; break;
			default: show_usage = 1; break;
			}/* switch */
			break;
		case 'F':
			FUCK_MODE = 1;
			speed = B9600;
			data_bit = CS8;
			stop_bit = 1;
			parity = P_EVEN;
			flow_control = F_HARD;
			break;
		case 'i':
			pipe_mode = 1;
			break;
		case 'j':
			rockwell_mode = 1;
			break;
		case 'l':
			logfile = optarg;
			break;
		case 'p':
			switch (optarg[0]) {
			case 'n': parity = P_NONE; break;
			case 'e': parity = P_EVEN; break;
			case 'o': parity = P_ODD; break;
			default: show_usage = 1; break;
			}/* switch */
			break;
		case 'P':
			port = strtol(optarg, NULL, 0);
			break;
		case 's':
			if (strcmp(optarg, "1") == 0)
				stop_bit = 1;
			else if (strcmp(optarg, "2") == 0)
				stop_bit = 2;
			else if (strcmp(optarg, "1.5") == 0)
				stop_bit = 3;
			else	
				show_usage = 1;
			break;
		case 'z':
			truncate_log = 1;
			break;
		}/* switch */
	}/* while */
	if (argc - optind != 1)
		show_usage++;
	if (show_usage) {
		fprintf(stderr, "%s\n", copyright);
		fprintf(stderr, usage_msg, myname, myname);
	}
	else {
		int err = 0;
		FILE *logfp = NULL;
		if (logfile != NULL) {
			logfp = fopen(logfile, (truncate_log ? "w" : "a"));
			if (logfp == NULL) {
				perror(logfile);
				err = -1;
			}
		}
		if (err == 0) {
			char *target = argv[optind];
			fprintf(stderr, "%s\n", copyright);
			fprintf(stderr, "Type \"Ctrl-M ~ .\" to exit.\n");
			if (*target == '/')
				nain(argv[optind], logfp);
			else
				oain(argv[optind], port, logfp);
			ex = 0;
		}
	}
	return ex;
}/* main */
